# Generated code do not commit.
file(TO_CMAKE_PATH "C:\\Users\\Kurt Kent Alabado\\Documents\\Projects\\flutter" FLUTTER_ROOT)
file(TO_CMAKE_PATH "C:\\Users\\Kurt Kent Alabado\\Documents\\Projects\\cenro_application\\cenro_application" PROJECT_DIR)

set(FLUTTER_VERSION "1.0.0+1" PARENT_SCOPE)
set(FLUTTER_VERSION_MAJOR 1 PARENT_SCOPE)
set(FLUTTER_VERSION_MINOR 0 PARENT_SCOPE)
set(FLUTTER_VERSION_PATCH 0 PARENT_SCOPE)
set(FLUTTER_VERSION_BUILD 1 PARENT_SCOPE)

# Environment variables to pass to tool_backend.sh
list(APPEND FLUTTER_TOOL_ENVIRONMENT
  "FLUTTER_ROOT=C:\\Users\\Kurt Kent Alabado\\Documents\\Projects\\flutter"
  "PROJECT_DIR=C:\\Users\\Kurt Kent Alabado\\Documents\\Projects\\cenro_application\\cenro_application"
  "FLUTTER_ROOT=C:\\Users\\Kurt Kent Alabado\\Documents\\Projects\\flutter"
  "FLUTTER_EPHEMERAL_DIR=C:\\Users\\Kurt Kent Alabado\\Documents\\Projects\\cenro_application\\cenro_application\\windows\\flutter\\ephemeral"
  "PROJECT_DIR=C:\\Users\\Kurt Kent Alabado\\Documents\\Projects\\cenro_application\\cenro_application"
  "FLUTTER_TARGET=C:\\Users\\Kurt Kent Alabado\\Documents\\Projects\\cenro_application\\cenro_application\\lib\\main.dart"
  "DART_DEFINES=RkxVVFRFUl9WRVJTSU9OPTMuNDQuMQ==,RkxVVFRFUl9DSEFOTkVMPXN0YWJsZQ==,RkxVVFRFUl9HSVRfVVJMPWh0dHBzOi8vZ2l0aHViLmNvbS9mbHV0dGVyL2ZsdXR0ZXIuZ2l0,RkxVVFRFUl9GUkFNRVdPUktfUkVWSVNJT049OTI0MTM0YTQ0Yw==,RkxVVFRFUl9FTkdJTkVfUkVWSVNJT049YzQxNmFjZmViOA==,RkxVVFRFUl9EQVJUX1ZFUlNJT049My4xMi4x"
  "DART_OBFUSCATION=false"
  "TRACK_WIDGET_CREATION=true"
  "TREE_SHAKE_ICONS=false"
  "PACKAGE_CONFIG=C:\\Users\\Kurt Kent Alabado\\Documents\\Projects\\cenro_application\\cenro_application\\.dart_tool\\package_config.json"
)
